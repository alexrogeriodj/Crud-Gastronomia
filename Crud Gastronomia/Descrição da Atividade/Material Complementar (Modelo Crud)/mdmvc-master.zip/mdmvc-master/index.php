<?php

require_once __DIR__ . '/core/util/functions.php';
require_once __DIR__ . '/vendor/autoload.php';

$dispatcher = new \Core\Classes\Dispatcher;