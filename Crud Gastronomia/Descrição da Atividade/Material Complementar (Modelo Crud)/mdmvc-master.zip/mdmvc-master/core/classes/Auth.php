<?php
/**
 * Author: Maycon de Moraes
 * Date:   30/10/2019
 * Description: Trait para validação do usuario
 */

namespace Core\Classes;

trait Auth
{
    private $inicioLogin;
    private $ativo;


    // verifica se o usuario esta logado
    public function isLogado()
    {
        
    }
}