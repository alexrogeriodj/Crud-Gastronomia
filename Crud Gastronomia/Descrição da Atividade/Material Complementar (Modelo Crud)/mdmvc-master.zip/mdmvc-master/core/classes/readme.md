# Pasta class

Nesta pasta colocaremos todos as classes do sistema, que servirão como core da aplicação.