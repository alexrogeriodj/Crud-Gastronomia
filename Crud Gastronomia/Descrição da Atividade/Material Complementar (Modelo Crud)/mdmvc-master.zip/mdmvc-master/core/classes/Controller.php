<?php
/**
 * Author: Maycon de Moraes
 * Date:   30/10/2019
 * Description: Classe que contem o controller padrão do framework
 */

namespace Core\Classes;

abstract class Controller
{
    public function index()
    {
        echo 'teste';
    }
}