# Pasta util

Nesta pasta colocaremos todos os arquivos que podem ser util em tempo desenvolvimento.