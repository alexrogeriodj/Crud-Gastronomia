<?php
/**
 * Exemplo de uma model
 * Author: Maycon de Moraes
 * Date:   30/10/2019
 */

namespace App\Model;

class Usuario extends \Core\Classes\Model
{
    protected $table = 'usuario';
} 