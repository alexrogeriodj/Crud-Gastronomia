# Pasta Application/model

Nesta pasta colocaremos todos as model da aplicação que estederam a model base