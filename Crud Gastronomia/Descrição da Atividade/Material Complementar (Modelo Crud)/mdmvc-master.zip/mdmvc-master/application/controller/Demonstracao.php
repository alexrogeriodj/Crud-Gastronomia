<?php

namespace App\Controller;

class Demonstracao
{
    public function index()
    {
        echo 'Classe Demonstração!';
    }

    public function teste()
    {
        echo 'metodo teste';
    }
}