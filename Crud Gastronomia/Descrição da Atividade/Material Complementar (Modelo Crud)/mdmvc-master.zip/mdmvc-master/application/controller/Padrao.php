<?php

namespace App\Controller;
use Core\Classes\Controller;

class Padrao extends Controller
{
    
}