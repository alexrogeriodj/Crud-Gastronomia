<?php

namespace App\Controller;

class Teste
{
    public function index()
    {
        echo 'Classe Teste - Metodo index';
    }

    public function meuMetodo()
    {
        echo 'Classe Teste - Meu Metodo';
    }

    public function lista()
    {
        echo 'Classe Teste - Metodo Lista';
    }
}