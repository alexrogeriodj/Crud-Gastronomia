# Pasta Application/controller

Nesta pasta colocaremos todos os controller da aplicação que estederam o controller base