# Pasta Application/config

Nesta pasta colocaremos todos os arquivos de configuração para a aplicação poder funcionar.