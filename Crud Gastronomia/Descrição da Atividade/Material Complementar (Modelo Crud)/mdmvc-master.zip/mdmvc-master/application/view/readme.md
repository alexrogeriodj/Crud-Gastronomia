# Pasta Application/view

Nesta pasta colocaremos todos as views (htmls, css, js) da aplicação que serão renderizadas para o usuário.